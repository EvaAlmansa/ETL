#!/usr/bin/env python

from distutils.core import setup

setup(
    name='ETL',
    version='0.0.0',
    description='',
    author='Eva Almansa',
    url='https://github.com/EvaAlmansa',
    packages=['ETL'],
    install_requires=[]
)
